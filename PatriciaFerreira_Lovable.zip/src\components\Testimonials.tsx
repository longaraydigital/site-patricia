import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface Testimonial {
  stars: number
  quote: string
  name: string
  role: string
  avatarGradient: string
}

const testimonials: Testimonial[] = [
  {
    stars: 5,
    quote: '"Depois de meses com dores crônicas nas costas, Patrícia me devolveu a qualidade de vida. Seu método é incrível e o atendimento personalizado fez toda a diferença."',
    name: 'Ana Carolina M.',
    role: 'Aluna há 2 anos',
    avatarGradient: 'linear-gradient(135deg,#c4a882,#8a6b50)',
  },
  {
    stars: 5,
    quote: '"Cheguei desacreditado, mas o Pilates com a Patrícia transformou minha postura e meu desempenho no trabalho. Recomendo para qualquer pessoa."',
    name: 'Roberto Alves',
    role: 'Aluno há 18 meses',
    avatarGradient: 'linear-gradient(135deg,#b8997a,#7a5e42)',
  },
  {
    stars: 5,
    quote: '"Fiz Pilates durante toda a gravidez e a Patrícia foi excepcional. Me senti segura, bem cuidada e minha recuperação pós-parto foi muito mais rápida."',
    name: 'Fernanda Lima',
    role: 'Aluna há 3 anos',
    avatarGradient: 'linear-gradient(135deg,#d4b896,#a07858)',
  },
  {
    stars: 5,
    quote: '"Nunca imaginei que homem pudesse se beneficiar tanto do Pilates. Após cirurgia no joelho, voltei a correr em metade do tempo previsto. Patrícia é excepcional."',
    name: 'Marcos Souza',
    role: 'Aluno há 14 meses',
    avatarGradient: 'linear-gradient(135deg,#c8a87a,#8a6040)',
  },
  {
    stars: 5,
    quote: '"Aos 65 anos, comecei o Pilates com a Patrícia e foi a melhor decisão da minha vida. Mais equilíbrio, menos dores, e uma energia que não sentia há anos!"',
    name: 'Luciana Pereira',
    role: 'Aluna há 4 anos',
    avatarGradient: 'linear-gradient(135deg,#e0c8a8,#b89068)',
  },
]

const CARD_WIDTH = 356 // 340px + 16px gap

const Testimonials: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const trackRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.reveal', el).forEach((revealEl) => {
        gsap.fromTo(
          revealEl,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: revealEl,
              start: 'top 88%',
              toggleActions: 'play none none none',
            },
          }
        )
      })
    }, el)

    return () => ctx.revert()
  }, [])

  const handlePrev = () => {
    trackRef.current?.scrollBy({ left: -CARD_WIDTH, behavior: 'smooth' })
  }

  const handleNext = () => {
    trackRef.current?.scrollBy({ left: CARD_WIDTH, behavior: 'smooth' })
  }

  return (
    <section id="depoimentos" style={{ background: 'var(--bg-light)' }} ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="reveal flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div>
            <div className="section-label">Depoimentos</div>
            <h2 className="section-title">O Que Dizem</h2>
            <h2 className="section-title" style={{ color: 'var(--secondary)', fontWeight: 400, fontStyle: 'normal' }}>Nossos Alunos</h2>
          </div>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button
              onClick={handlePrev}
              aria-label="Depoimento anterior"
              style={{ width: 44, height: 44, borderRadius: '50%', border: '1.5px solid var(--bg-dark)', background: 'none', cursor: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem', color: 'var(--secondary)', transition: 'all 0.2s' }}
            >
              ←
            </button>
            <button
              onClick={handleNext}
              aria-label="Próximo depoimento"
              style={{ width: 44, height: 44, borderRadius: '50%', border: '1.5px solid var(--bg-dark)', background: 'none', cursor: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem', color: 'var(--secondary)', transition: 'all 0.2s' }}
            >
              →
            </button>
          </div>
        </div>

        <div className="testimonials-wrapper reveal" ref={trackRef} role="list">
          <div style={{ display: 'flex', gap: '1.5rem', paddingBottom: '1rem' }}>
            {testimonials.map((t) => (
              <div key={t.name} className="testimonial-card" role="listitem" aria-label={`Depoimento de ${t.name}`}>
                <div className="stars" aria-label={`${t.stars} estrelas`}>{'★'.repeat(t.stars)}</div>
                <blockquote className="testimonial-text">{t.quote}</blockquote>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
                  <div style={{ width: 42, height: 42, borderRadius: '50%', background: t.avatarGradient, flexShrink: 0 }} role="img" aria-label={`Foto de ${t.name}`} />
                  <div>
                    <div style={{ fontFamily: "'Manrope', sans-serif", fontWeight: 600, fontSize: '0.9rem', color: 'var(--primary)' }}>{t.name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--secondary)', opacity: 0.65 }}>{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Rating summary */}
        <div className="reveal" style={{ display: 'flex', alignItems: 'center', gap: '2rem', marginTop: '2.5rem', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ fontFamily: "'Noto Serif', serif", fontSize: '3.5rem', fontWeight: 700, color: 'var(--primary)', lineHeight: 1 }}>4.9</div>
            <div>
              <div className="stars" style={{ fontSize: '1.1rem' }} aria-label="4.9 de 5 estrelas">★★★★★</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--secondary)', opacity: 0.65, marginTop: '0.3rem' }}>Baseado em 120+ avaliações</div>
            </div>
          </div>
          <div style={{ height: '3rem', width: 1, background: 'var(--bg-dark)' }} aria-hidden="true" />
          <div style={{ fontSize: '0.9rem', color: 'var(--secondary)' }}>
            <strong style={{ color: 'var(--primary)' }}>98%</strong> dos alunos recomendam o estúdio
          </div>
        </div>
      </div>
    </section>
  )
}

export default Testimonials
