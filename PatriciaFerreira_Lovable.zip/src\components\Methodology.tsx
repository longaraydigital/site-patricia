import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const pillars = [
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="1.6" strokeLinecap="round">
        <circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" />
      </svg>
    ),
    title: 'Precisão',
    desc: 'Cada movimento é executado com atenção meticulosa à forma e alinhamento. A precisão garante que o esforço seja direcionado exatamente onde é necessário, maximizando resultados e prevenindo lesões.',
    items: ['Alinhamento postural', 'Ativação muscular correta', 'Controle respiratório'],
    ariaLabel: 'Pilar Precisão',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="1.6" strokeLinecap="round">
        <circle cx="12" cy="4" r="1.5" />
        <path d="M8 8c0 0 1.5 2 4 2s4-2 4-2" />
        <path d="M6 14c1-2 3-3 6-3s5 1 6 3" />
        <path d="M9 14l-2 5" />
        <path d="M15 14l2 5" />
        <path d="M10 19h4" />
      </svg>
    ),
    title: 'Consciência Corporal',
    desc: 'Desenvolvemos uma conexão profunda entre mente e corpo. Quando você entende como seu corpo se move, torna-se capaz de tomar decisões mais sábias em toda atividade física e nas rotinas diárias.',
    items: ['Conexão mente-corpo', 'Propriocepção ativa', 'Fluxo de movimento'],
    ariaLabel: 'Pilar Consciência Corporal',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="1.6" strokeLinecap="round">
        <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10" />
        <path d="M12 6v6l4 2" />
        <path d="M18 2l4 4-4 4" />
        <path d="M22 6h-6" />
      </svg>
    ),
    title: 'Evolução Contínua',
    desc: 'O corpo humano tem uma capacidade extraordinária de adaptação e crescimento. Trabalhamos progressivamente para expandir suas capacidades, respeitando seus limites e celebrando cada conquista.',
    items: ['Progressão gradual', 'Planos personalizados', 'Acompanhamento contínuo'],
    ariaLabel: 'Pilar Evolução Contínua',
  },
]

const modalities = [
  { emoji: '🛏️', title: 'Solo', sub: 'Mat Pilates' },
  { emoji: '⚙️', title: 'Reformer', sub: 'Equipamento' },
  { emoji: '🩺', title: 'Clínico', sub: 'Reabilitação' },
  { emoji: '🤰', title: 'Gestante', sub: 'Pré e Pós-natal' },
  { emoji: '👴', title: 'Sênior', sub: 'Terceira idade' },
]

const Methodology: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.reveal', el).forEach((revealEl) => {
        gsap.fromTo(
          revealEl,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: revealEl,
              start: 'top 88%',
              toggleActions: 'play none none none',
            },
          }
        )
      })

      gsap.utils.toArray<HTMLElement>('.card', el).forEach((card, i) => {
        gsap.fromTo(
          card,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.85,
            ease: 'power3.out',
            delay: i * 0.12,
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none none',
            },
          }
        )
      })
    }, el)

    return () => ctx.revert()
  }, [])

  return (
    <section id="metodologia" style={{ background: 'var(--bg-light)' }} ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center reveal" style={{ maxWidth: 600, margin: '0 auto 4rem' }}>
          <div className="section-label">Nossa Abordagem</div>
          <h2 className="section-title">Os Três Pilares</h2>
          <h2 className="section-title" style={{ color: 'var(--secondary)', fontWeight: 400, fontStyle: 'normal' }}>do Método Patrícia</h2>
          <p style={{ fontFamily: "'Manrope', sans-serif", fontSize: '1rem', lineHeight: 1.75, color: 'var(--secondary)', marginTop: '1.25rem', opacity: 0.85 }}>
            Uma metodologia desenvolvida ao longo de 12 anos, integrando as melhores práticas do Pilates com as necessidades individuais de cada aluno.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {pillars.map((pilar) => (
            <div key={pilar.title} className="card" style={{ padding: '2.5rem 2rem' }} role="article" aria-label={pilar.ariaLabel}>
              <div className="method-icon" aria-hidden="true">{pilar.icon}</div>
              <h3 style={{ fontFamily: "'Noto Serif', serif", fontStyle: 'italic', fontWeight: 700, fontSize: '1.5rem', color: 'var(--primary)', marginBottom: '0.875rem' }}>{pilar.title}</h3>
              <p style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.95rem', lineHeight: 1.75, color: 'var(--secondary)', opacity: 0.85 }}>{pilar.desc}</p>
              <div style={{ marginTop: '1.75rem', paddingTop: '1.75rem', borderTop: '1px solid var(--bg-dark)' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                  {pilar.items.map((item) => (
                    <div key={item} style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.85rem', color: 'var(--secondary)' }}>
                      <span style={{ color: 'var(--primary)', fontSize: '0.8rem' }}>✓</span> {item}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modalidades */}
        <div className="reveal" style={{ marginTop: '4rem', background: 'var(--bg-mid)', borderRadius: '1.75rem', padding: '2.5rem 3rem' }}>
          <div style={{ marginBottom: '1.5rem' }}>
            <div className="section-label">Modalidades Oferecidas</div>
          </div>
          <div className="grid md:grid-cols-5 gap-4" role="list">
            {modalities.map((mod) => (
              <div key={mod.title} style={{ textAlign: 'center', padding: '1.5rem 1rem', background: '#fff', borderRadius: '1.25rem', boxShadow: 'var(--shadow)' }} role="listitem">
                <div style={{ fontSize: '1.75rem', marginBottom: '0.5rem' }} aria-hidden="true">{mod.emoji}</div>
                <div style={{ fontFamily: "'Noto Serif', serif", fontWeight: 600, fontSize: '0.95rem', color: 'var(--primary)' }}>{mod.title}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--secondary)', opacity: 0.7, marginTop: '0.2rem' }}>{mod.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Methodology
