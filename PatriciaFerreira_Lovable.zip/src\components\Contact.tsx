import React, { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const Contact: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({
    nome: '',
    telefone: '',
    email: '',
    modalidade: '',
    mensagem: '',
  })

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.reveal', el).forEach((revealEl) => {
        gsap.fromTo(
          revealEl,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: revealEl,
              start: 'top 88%',
              toggleActions: 'play none none none',
            },
          }
        )
      })
    }, el)

    return () => ctx.revert()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => {
      setSubmitted(false)
      setForm({ nome: '', telefone: '', email: '', modalidade: '', mensagem: '' })
    }, 4000)
  }

  return (
    <section id="contato" style={{ background: 'var(--bg-light)' }} ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16">

          {/* Form */}
          <div className="reveal">
            <div className="section-label">Contato</div>
            <h2 className="section-title">Agende sua</h2>
            <h2 className="section-title" style={{ color: 'var(--secondary)', fontWeight: 400, fontStyle: 'normal', marginBottom: '0.5rem' }}>Aula Experimental</h2>
            <p style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.95rem', lineHeight: 1.75, color: 'var(--secondary)', opacity: 0.8, marginBottom: '2.25rem' }}>
              Primeira aula totalmente gratuita e sem compromisso. Venha conhecer o método e sentir a diferença.
            </p>

            <form onSubmit={handleSubmit} noValidate aria-label="Formulário de contato">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="form-group">
                  <label className="form-label" htmlFor="nome">Nome Completo</label>
                  <input type="text" id="nome" name="nome" className="form-input" placeholder="Seu nome" required aria-required="true" value={form.nome} onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="telefone">Telefone / WhatsApp</label>
                  <input type="tel" id="telefone" name="telefone" className="form-input" placeholder="(11) 99999-0000" required aria-required="true" value={form.telefone} onChange={handleChange} />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="email">E-mail</label>
                <input type="email" id="email" name="email" className="form-input" placeholder="seu@email.com" required aria-required="true" value={form.email} onChange={handleChange} />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="modalidade">Modalidade de Interesse</label>
                <select id="modalidade" name="modalidade" className="form-input" aria-label="Selecione a modalidade" value={form.modalidade} onChange={handleChange}>
                  <option value="">Selecione uma modalidade</option>
                  <option value="solo">Pilates Solo (Mat)</option>
                  <option value="reformer">Pilates Reformer</option>
                  <option value="clinico">Pilates Clínico / Reabilitação</option>
                  <option value="gestante">Pilates para Gestantes</option>
                  <option value="senior">Pilates Sênior</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="mensagem">Mensagem (opcional)</label>
                <textarea id="mensagem" name="mensagem" className="form-input" placeholder="Conte-nos sobre seus objetivos ou necessidades específicas…" value={form.mensagem} onChange={handleChange} />
              </div>

              <button
                type="submit"
                className="btn-primary"
                disabled={submitted}
                aria-label="Enviar formulário de agendamento"
                style={{
                  width: '100%',
                  fontSize: '1rem',
                  padding: '1rem',
                  marginTop: '0.5rem',
                  cursor: 'none',
                  background: submitted ? '#5a8a5a' : undefined,
                }}
              >
                {submitted ? '✓ Mensagem enviada! Entraremos em contato.' : 'Agendar Aula Gratuita →'}
              </button>
            </form>
          </div>

          {/* Info */}
          <div className="reveal">
            <div style={{ marginBottom: '2rem' }}>
              {/* Address */}
              <div className="contact-info-item" role="listitem" aria-label="Endereço do estúdio">
                <div className="contact-icon" aria-hidden="true">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
                    <circle cx="12" cy="9" r="2.5" />
                  </svg>
                </div>
                <div>
                  <div style={{ fontFamily: "'Manrope', sans-serif", fontWeight: 600, fontSize: '0.9rem', color: 'var(--primary)', marginBottom: '0.25rem' }}>Endereço</div>
                  <div style={{ fontSize: '0.9rem', color: 'var(--secondary)' }}>Av. da Elegância, 1200 — Jardins</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--secondary)', opacity: 0.7 }}>São Paulo, SP · CEP 01310-100</div>
                </div>
              </div>

              {/* Phone */}
              <div className="contact-info-item" role="listitem" aria-label="Telefone de contato">
                <div className="contact-icon" aria-hidden="true">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.18h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.78a16 16 0 0 0 6.29 6.29l.96-.96a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                </div>
                <div>
                  <div style={{ fontFamily: "'Manrope', sans-serif", fontWeight: 600, fontSize: '0.9rem', color: 'var(--primary)', marginBottom: '0.25rem' }}>Telefone / WhatsApp</div>
                  <div style={{ fontSize: '0.9rem', color: 'var(--secondary)' }}>+55 (11) 99999-8888</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--secondary)', opacity: 0.7 }}>Seg–Sex, 7h–20h · Sáb 8h–14h</div>
                </div>
              </div>

              {/* Email */}
              <div className="contact-info-item" role="listitem" aria-label="E-mail de contato">
                <div className="contact-icon" aria-hidden="true">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                    <polyline points="22,6 12,13 2,6" />
                  </svg>
                </div>
                <div>
                  <div style={{ fontFamily: "'Manrope', sans-serif", fontWeight: 600, fontSize: '0.9rem', color: 'var(--primary)', marginBottom: '0.25rem' }}>E-mail</div>
                  <div style={{ fontSize: '0.9rem', color: 'var(--secondary)' }}>contato@patriciaferreirapiates.com.br</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--secondary)', opacity: 0.7 }}>Resposta em até 24 horas</div>
                </div>
              </div>
            </div>

            {/* Map placeholder */}
            <div className="map-placeholder" style={{ height: 230 }} role="img" aria-label="Mapa da localização do estúdio">
              <div style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }} aria-hidden="true">🗺️</div>
                <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.8rem', fontWeight: 600, color: 'var(--secondary)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Mapa do Estúdio</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--secondary)', opacity: 0.6, marginTop: '0.25rem' }}>Av. da Elegância, 1200 — Jardins, SP</div>
              </div>
            </div>

            {/* Social links */}
            <div style={{ display: 'flex', gap: '0.875rem', marginTop: '1.5rem' }} role="list" aria-label="Redes sociais">
              {/* Instagram */}
              <a href="#" style={{ width: 44, height: 44, borderRadius: '0.875rem', background: 'rgba(104,69,46,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)', textDecoration: 'none', transition: 'all 0.2s', cursor: 'none' }} aria-label="Instagram" role="listitem">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="2" width="20" height="20" rx="5" />
                  <circle cx="12" cy="12" r="4" />
                  <circle cx="17.5" cy="6.5" r="0.8" fill="currentColor" stroke="none" />
                </svg>
              </a>
              {/* WhatsApp */}
              <a href="#" style={{ width: 44, height: 44, borderRadius: '0.875rem', background: 'rgba(104,69,46,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)', textDecoration: 'none', transition: 'all 0.2s', cursor: 'none' }} aria-label="WhatsApp" role="listitem">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                </svg>
              </a>
              {/* Facebook */}
              <a href="#" style={{ width: 44, height: 44, borderRadius: '0.875rem', background: 'rgba(104,69,46,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)', textDecoration: 'none', transition: 'all 0.2s', cursor: 'none' }} aria-label="Facebook" role="listitem">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
