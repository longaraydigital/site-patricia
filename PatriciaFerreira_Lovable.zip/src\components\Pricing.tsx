import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface Plan {
  name: string
  price: string
  period: string
  featured: boolean
  badge?: string
  features: { text: string; included: boolean }[]
  ariaLabel: string
}

const plans: Plan[] = [
  {
    name: 'Essencial',
    price: '190',
    period: 'por mês · 1× por semana',
    featured: false,
    features: [
      { text: '4 aulas mensais', included: true },
      { text: 'Avaliação postural inicial', included: true },
      { text: 'Plano de treino personalizado', included: true },
      { text: 'Acesso a materiais digitais', included: true },
      { text: 'Aulas em dupla disponíveis', included: false },
      { text: 'Suporte prioritário', included: false },
    ],
    ariaLabel: 'Plano Essencial, 1 vez por semana, R$190',
  },
  {
    name: 'Equilíbrio',
    price: '300',
    period: 'por mês · 2× por semana',
    featured: true,
    badge: '✦ Mais Popular',
    features: [
      { text: '8 aulas mensais', included: true },
      { text: 'Avaliação postural inicial', included: true },
      { text: 'Plano de treino personalizado', included: true },
      { text: 'Acesso a materiais digitais', included: true },
      { text: 'Aulas em dupla disponíveis', included: true },
      { text: 'Suporte prioritário', included: false },
    ],
    ariaLabel: 'Plano Mais Popular, 2 vezes por semana, R$300',
  },
  {
    name: 'Transformação',
    price: '370',
    period: 'por mês · 3× por semana',
    featured: false,
    features: [
      { text: '12 aulas mensais', included: true },
      { text: 'Avaliação postural inicial', included: true },
      { text: 'Plano de treino personalizado', included: true },
      { text: 'Acesso a materiais digitais', included: true },
      { text: 'Aulas em dupla disponíveis', included: true },
      { text: 'Suporte prioritário via WhatsApp', included: true },
    ],
    ariaLabel: 'Plano Transformação, 3 vezes por semana, R$370',
  },
]

const Pricing: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.reveal', el).forEach((revealEl) => {
        gsap.fromTo(
          revealEl,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: revealEl,
              start: 'top 88%',
              toggleActions: 'play none none none',
            },
          }
        )
      })

      gsap.utils.toArray<HTMLElement>('.plan-card', el).forEach((card, i) => {
        gsap.fromTo(
          card,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.85,
            ease: 'power3.out',
            delay: i * 0.12,
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none none',
            },
          }
        )
      })
    }, el)

    return () => ctx.revert()
  }, [])

  return (
    <section id="planos" style={{ background: 'var(--bg-mid)' }} ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center reveal" style={{ maxWidth: 560, margin: '0 auto 4rem' }}>
          <div className="section-label">Investimento</div>
          <h2 className="section-title">Escolha seu Plano</h2>
          <p style={{ fontFamily: "'Manrope', sans-serif", fontSize: '1rem', lineHeight: 1.75, color: 'var(--secondary)', marginTop: '1.25rem', opacity: 0.85 }}>
            Planos mensais com aulas individuais ou em dupla. Primeira aula experimental gratuita.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 items-start">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`plan-card reveal${plan.featured ? ' featured' : ''}`}
              style={plan.featured ? { transform: 'scale(1.03)' } : undefined}
              role="article"
              aria-label={plan.ariaLabel}
            >
              {plan.badge && (
                <div className="plan-badge" aria-label="Plano mais popular">{plan.badge}</div>
              )}

              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{
                  fontFamily: "'Manrope', sans-serif",
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: plan.featured ? 'rgba(252,249,244,0.55)' : 'var(--secondary)',
                  opacity: plan.featured ? 1 : 0.6,
                  marginBottom: '0.75rem',
                }}>
                  {plan.name}
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.35rem' }}>
                  <span style={{ fontFamily: "'Noto Serif', serif", fontSize: '0.95rem', fontWeight: 600, color: plan.featured ? 'rgba(252,249,244,0.8)' : 'var(--primary)' }}>R$</span>
                  <span className="plan-price" style={{ color: plan.featured ? '#fcf9f4' : 'var(--primary)' }}>{plan.price}</span>
                </div>
                <div className="plan-period" style={{ color: plan.featured ? 'rgba(252,249,244,0.65)' : 'var(--secondary)' }}>{plan.period}</div>
              </div>

              <div style={{ margin: '1.5rem 0' }}>
                {plan.features.map((feat) => (
                  <div
                    key={feat.text}
                    className="plan-feature"
                    style={{
                      color: plan.featured ? '#fcf9f4' : undefined,
                      opacity: feat.included ? 1 : 0.4,
                    }}
                  >
                    {feat.included
                      ? <span className="check-icon">✓</span>
                      : <span>—</span>
                    }
                    <span style={feat.included ? undefined : { marginLeft: '0.6rem' }}>{feat.text}</span>
                  </div>
                ))}
              </div>

              {plan.featured ? (
                <a
                  href="#contato"
                  className="btn-primary"
                  style={{ display: 'block', textAlign: 'center', fontSize: '0.9rem', padding: '0.8rem 1.5rem', marginTop: '1.5rem', background: '#fcf9f4', color: 'var(--primary)', cursor: 'none' }}
                  aria-label={`Começar com o Plano ${plan.name}`}
                >
                  Começar Agora
                </a>
              ) : (
                <a
                  href="#contato"
                  className="btn-outline"
                  style={{ display: 'block', textAlign: 'center', fontSize: '0.9rem', padding: '0.8rem 1.5rem', marginTop: '1.5rem', cursor: 'none' }}
                  aria-label={`Começar com o Plano ${plan.name}`}
                >
                  Começar Agora
                </a>
              )}
            </div>
          ))}
        </div>

        <p className="reveal" style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--secondary)', opacity: 0.6, marginTop: '2rem' }}>
          * Primeira aula experimental gratuita e sem compromisso. Condições especiais para pagamento anual.
        </p>
      </div>
    </section>
  )
}

export default Pricing
