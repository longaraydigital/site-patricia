import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'

const Hero: React.FC = () => {
  const wordRefs = useRef<(HTMLSpanElement | null)[]>([])
  const revealRefs = useRef<(HTMLElement | null)[]>([])

  useEffect(() => {
    // Hero headline word stagger
    wordRefs.current.forEach((el, i) => {
      if (!el) return
      gsap.from(el, {
        y: '110%',
        duration: 1.0,
        delay: 0.2 + i * 0.15,
        ease: 'power4.out',
      })
    })

    // Hero reveal elements
    revealRefs.current.forEach((el, i) => {
      if (!el) return
      gsap.from(el, {
        opacity: 0,
        y: 28,
        duration: 0.9,
        delay: 0.7 + i * 0.18,
        ease: 'power3.out',
      })
    })
  }, [])

  const setWordRef = (i: number) => (el: HTMLSpanElement | null) => {
    wordRefs.current[i] = el
  }

  const setRevealRef = (i: number) => (el: HTMLElement | null) => {
    revealRefs.current[i] = el
  }

  return (
    <section id="hero" aria-label="Bem-vindo ao Patrícia Ferreira Pilates">
      {/* Decorative floating shapes */}
      <div
        className="float-shape"
        style={{
          width: 400,
          height: 400,
          background: 'radial-gradient(circle, rgba(104,69,46,0.07), transparent 70%)',
          top: '-10%',
          right: '-8%',
          animation: 'floatSlow 12s ease-in-out infinite',
        }}
        aria-hidden="true"
      />
      <div
        className="float-shape"
        style={{
          width: 280,
          height: 280,
          background: 'radial-gradient(circle, rgba(106,92,70,0.06), transparent 70%)',
          bottom: '10%',
          left: '-5%',
          animation: 'float 9s ease-in-out infinite 1s',
        }}
        aria-hidden="true"
      />

      <div className="hero-content max-w-7xl mx-auto px-6 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-32">
          {/* Text */}
          <div>
            <div
              ref={setRevealRef(0) as React.RefCallback<HTMLDivElement>}
              className="section-label"
              style={{ marginBottom: '1.5rem', opacity: 1 }}
            >
              Studio Certificado de Pilates — São Paulo
            </div>

            <h1
              className="hero-headline"
              style={{ fontSize: 'clamp(2.75rem, 6vw, 5rem)', marginBottom: '1.75rem' }}
              aria-label="A Essência do Bem-Estar e Equilíbrio"
            >
              <span className="hero-word">
                <span className="hero-word-inner" ref={setWordRef(0)}>A Essência</span>
              </span>
              <br />
              <span className="hero-word">
                <span className="hero-word-inner" ref={setWordRef(1)}>do Bem-Estar</span>
              </span>
              <br />
              <span className="hero-word" style={{ color: 'var(--secondary)', fontStyle: 'italic', fontWeight: 400 }}>
                <span className="hero-word-inner" ref={setWordRef(2)}>e Equilíbrio</span>
              </span>
            </h1>

            <p
              ref={setRevealRef(1) as React.RefCallback<HTMLParagraphElement>}
              style={{
                fontFamily: "'Manrope', sans-serif",
                fontSize: '1.1rem',
                lineHeight: 1.75,
                color: 'var(--secondary)',
                maxWidth: 480,
                marginBottom: '2.5rem',
                opacity: 1,
              }}
            >
              Movimento consciente, corpo fortalecido e mente em paz. Uma experiência transformadora com mais de uma década de excelência.
            </p>

            <div
              ref={setRevealRef(2) as React.RefCallback<HTMLDivElement>}
              className="flex flex-wrap gap-4 items-center"
              style={{ opacity: 1 }}
            >
              <a href="#contato" className="btn-primary" style={{ fontSize: '1rem', padding: '0.9rem 2.25rem' }}>
                Agende sua Aula Experimental
              </a>
              <a href="#sobre" className="btn-outline">
                Conheça o Método
              </a>
            </div>

            {/* Trust signals */}
            <div
              ref={setRevealRef(3) as React.RefCallback<HTMLDivElement>}
              className="flex items-center gap-4 mt-8"
              style={{ opacity: 1 }}
            >
              <div style={{ display: 'flex' }}>
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#c4a882,#a07858)', border: '2px solid #fcf9f4' }} />
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#b8997a,#8a6b50)', border: '2px solid #fcf9f4', marginLeft: -8 }} />
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#d4b896,#c09878)', border: '2px solid #fcf9f4', marginLeft: -8 }} />
              </div>
              <div>
                <div style={{ color: 'var(--primary)', fontSize: '0.9rem', fontWeight: 600 }}>+500 alunos transformados</div>
                <div style={{ color: 'var(--secondary)', fontSize: '0.75rem', opacity: 0.7 }}>⭐⭐⭐⭐⭐ 98% satisfação</div>
              </div>
            </div>
          </div>

          {/* Decorative card stack */}
          <div className="hidden lg:flex flex-col items-center justify-center relative">
            <div style={{ position: 'relative', width: 380, height: 460 }}>
              {/* Back card */}
              <div style={{ position: 'absolute', inset: 0, borderRadius: '1.75rem', background: 'linear-gradient(145deg,#e8dfd5,#d6cbbf)', transform: 'rotate(4deg)', boxShadow: 'var(--shadow)' }} />
              {/* Main photo */}
              <div style={{ position: 'absolute', inset: 8, borderRadius: '1.5rem', overflow: 'hidden', background: 'linear-gradient(160deg,#c4a882 0%,#8a6b50 40%,#68452e 100%)', display: 'flex', alignItems: 'flex-end', padding: '2rem' }}>
                <div>
                  <div style={{ fontFamily: "'Noto Serif', serif", fontStyle: 'italic', fontWeight: 600, color: 'rgba(252,249,244,0.9)', fontSize: '1.2rem', marginBottom: '0.25rem' }}>Patrícia Ferreira</div>
                  <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.75rem', fontWeight: 500, color: 'rgba(252,249,244,0.65)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Instrutora Certificada</div>
                </div>
              </div>
              {/* Badge years */}
              <div style={{ position: 'absolute', top: '-1rem', right: '-1.5rem', background: '#fcf9f4', borderRadius: '1rem', padding: '0.875rem 1.25rem', boxShadow: '0 10px 30px rgba(47,21,4,0.12)', zIndex: 10 }}>
                <div style={{ fontFamily: "'Noto Serif', serif", fontWeight: 700, fontSize: '1.75rem', color: 'var(--primary)', lineHeight: 1 }}>12+</div>
                <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.7rem', fontWeight: 600, letterSpacing: '0.08em', color: 'var(--secondary)', opacity: 0.7, textTransform: 'uppercase' }}>Anos de<br />Experiência</div>
              </div>
              {/* Badge CREF */}
              <div style={{ position: 'absolute', bottom: '-1.25rem', left: '-1.75rem', background: 'var(--primary)', borderRadius: '1rem', padding: '0.875rem 1.25rem', boxShadow: '0 10px 30px rgba(47,21,4,0.25)', zIndex: 10 }}>
                <div style={{ fontFamily: "'Noto Serif', serif", fontWeight: 700, fontSize: '1.5rem', color: '#fcf9f4', lineHeight: 1 }}>CREF</div>
                <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.7rem', fontWeight: 500, color: 'rgba(252,249,244,0.7)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Certificada</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="scroll-indicator" aria-hidden="true">
        <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--primary)', opacity: 0.45, marginBottom: '0.5rem' }}>
          Rolar
        </div>
        <div className="scroll-dot" />
        <div className="scroll-dot" />
        <div className="scroll-dot" />
      </div>
    </section>
  )
}

export default Hero
