import React, { useEffect, useRef, useState } from 'react'

interface StatItem {
  target: number
  suffix: string
  label: string
}

const STATS: StatItem[] = [
  { target: 12, suffix: '+', label: 'Anos de Experiência' },
  { target: 500, suffix: '+', label: 'Alunos Atendidos' },
  { target: 98, suffix: '%', label: 'Taxa de Satisfação' },
  { target: 5, suffix: '', label: 'Modalidades' },
]

function useCounter(target: number, active: boolean): number {
  const [value, setValue] = useState(0)

  useEffect(() => {
    if (!active) return
    const duration = 1800
    const start = performance.now()

    function update(now: number) {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setValue(Math.round(eased * target))
      if (progress < 1) requestAnimationFrame(update)
    }

    requestAnimationFrame(update)
  }, [active, target])

  return value
}

const StatCounter: React.FC<{ item: StatItem; active: boolean }> = ({ item, active }) => {
  const value = useCounter(item.target, active)
  return (
    <div className="stat-item">
      <div className="stat-number">
        {value}{item.suffix}
      </div>
      <div className="stat-label">{item.label}</div>
    </div>
  )
}

const Stats: React.FC = () => {
  const stripRef = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(false)

  useEffect(() => {
    const el = stripRef.current
    if (!el) return

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(true)
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.3 }
    )

    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  return (
    <div className="stats-strip" aria-label="Números do estúdio" ref={stripRef}>
      <div className="max-w-5xl mx-auto px-6">
        <div className="flex flex-wrap items-center justify-around gap-6 md:gap-0">
          {STATS.map((item, i) => (
            <React.Fragment key={item.label}>
              <StatCounter item={item} active={active} />
              {i < STATS.length - 1 && (
                <div className="stat-divider hidden md:block" aria-hidden="true" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Stats
