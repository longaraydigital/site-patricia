import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface GalleryItem {
  gradient: string
  label: string
  ariaLabel: string
}

const items: GalleryItem[] = [
  { gradient: 'linear-gradient(145deg,#c4a882,#68452e)', label: 'Sala Principal', ariaLabel: 'Sala principal do estúdio' },
  { gradient: 'linear-gradient(145deg,#b8997a,#7a5e42)', label: 'Reformer', ariaLabel: 'Equipamentos Reformer' },
  { gradient: 'linear-gradient(145deg,#e8dfd5,#c4a882)', label: 'Área Solo', ariaLabel: 'Área de solo' },
  { gradient: 'linear-gradient(160deg,#a07858,#68452e)', label: 'Equipamentos', ariaLabel: 'Equipamentos e acessórios' },
  { gradient: 'linear-gradient(145deg,#d4bfa6,#9a7860)', label: 'Recepção', ariaLabel: 'Recepção do estúdio' },
  { gradient: 'linear-gradient(135deg,#c8a87a,#8a6040)', label: 'Relaxamento', ariaLabel: 'Área de relaxamento' },
]

const Gallery: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const itemRefs = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return

    const ctx = gsap.context(() => {
      // Reveal header
      gsap.utils.toArray<HTMLElement>('.reveal', el).forEach((revealEl) => {
        gsap.fromTo(
          revealEl,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: revealEl,
              start: 'top 88%',
              toggleActions: 'play none none none',
            },
          }
        )
      })

      // Parallax on each gallery item
      itemRefs.current.forEach((itemEl, i) => {
        if (!itemEl) return
        gsap.to(itemEl, {
          y: i % 2 === 0 ? -40 : 40,
          ease: 'none',
          scrollTrigger: {
            trigger: itemEl,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 1.5,
          },
        })
      })
    }, el)

    return () => ctx.revert()
  }, [])

  return (
    <section id="estudio" style={{ background: 'var(--bg-mid)' }} ref={sectionRef} aria-label="Galeria do Estúdio">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center reveal" style={{ marginBottom: '3.5rem' }}>
          <div className="section-label">Galeria</div>
          <h2 className="section-title">Conheça o Estúdio</h2>
        </div>

        <div className="gallery-grid reveal">
          {items.map((item, i) => (
            <div
              key={item.label}
              ref={(el) => { itemRefs.current[i] = el }}
              className="gallery-item"
              style={{ background: item.gradient }}
              role="img"
              aria-label={item.ariaLabel}
            >
              <div className="gallery-item-label">{item.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Gallery
