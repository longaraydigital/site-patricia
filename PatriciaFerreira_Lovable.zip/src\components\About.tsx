import React, { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

function useCounter(target: number, active: boolean): number {
  const [value, setValue] = useState(0)

  useEffect(() => {
    if (!active) return
    const duration = 1800
    const start = performance.now()

    function update(now: number) {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setValue(Math.round(eased * target))
      if (progress < 1) requestAnimationFrame(update)
    }

    requestAnimationFrame(update)
  }, [active, target])

  return value
}

const About: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [countersActive, setCountersActive] = useState(false)

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.reveal', el).forEach((revealEl) => {
        gsap.fromTo(
          revealEl,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: revealEl,
              start: 'top 88%',
              toggleActions: 'play none none none',
            },
          }
        )
      })
    }, el)

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setCountersActive(true)
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.3 }
    )

    observer.observe(el)

    return () => {
      ctx.revert()
      observer.disconnect()
    }
  }, [])

  const alunos = useCounter(500, countersActive)
  const anos = useCounter(12, countersActive)
  const modalidades = useCounter(5, countersActive)

  return (
    <section id="sobre" style={{ background: 'var(--bg-mid)' }} ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">

          {/* Photo side */}
          <div className="relative reveal">
            <div
              className="tilted-frame photo-placeholder"
              style={{
                background: 'linear-gradient(145deg,#d4bfa6 0%,#a07858 50%,#68452e 100%)',
                height: 520,
                display: 'flex',
                alignItems: 'flex-end',
                padding: '2.5rem',
              }}
              role="img"
              aria-label="Foto da instrutora Patrícia Ferreira"
            >
              <div>
                <div style={{ fontFamily: "'Noto Serif', serif", fontStyle: 'italic', fontSize: '1.35rem', fontWeight: 600, color: 'rgba(252,249,244,0.95)' }}>Patrícia Ferreira</div>
                <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.75rem', fontWeight: 500, color: 'rgba(252,249,244,0.6)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: '0.25rem' }}>Foto da Instrutora</div>
              </div>
            </div>

            {/* Floating cards */}
            <div className="card reveal" style={{ position: 'absolute', top: '2rem', right: '-2rem', padding: '1.25rem 1.5rem', zIndex: 10, borderRadius: '1.25rem', minWidth: 130, textAlign: 'center' }} aria-label="Especialização em Reabilitação">
              <div style={{ fontSize: '1.75rem', marginBottom: '0.35rem' }}>🏆</div>
              <div style={{ fontFamily: "'Noto Serif', serif", fontWeight: 700, fontSize: '1rem', color: 'var(--primary)' }}>Especialista</div>
              <div style={{ fontSize: '0.7rem', color: 'var(--secondary)', opacity: 0.7, marginTop: '0.2rem' }}>Reabilitação</div>
            </div>

            <div className="card reveal" style={{ position: 'absolute', bottom: '3rem', right: '-2rem', padding: '1.25rem 1.5rem', zIndex: 10, borderRadius: '1.25rem', minWidth: 130, textAlign: 'center' }} aria-label="Método Original Pilates">
              <div style={{ fontSize: '1.75rem', marginBottom: '0.35rem' }}>✦</div>
              <div style={{ fontFamily: "'Noto Serif', serif", fontWeight: 700, fontSize: '1rem', color: 'var(--primary)' }}>Método</div>
              <div style={{ fontSize: '0.7rem', color: 'var(--secondary)', opacity: 0.7, marginTop: '0.2rem' }}>Original Pilates</div>
            </div>
          </div>

          {/* Text side */}
          <div className="reveal">
            <div className="section-label">Sobre a Instrutora</div>
            <h2 className="section-title" style={{ marginBottom: 0 }}>Uma Jornada</h2>
            <h2 className="section-title" style={{ color: 'var(--secondary)', fontWeight: 400 }}>de Transformação</h2>
            <div className="section-divider" />

            <p style={{ fontFamily: "'Manrope', sans-serif", fontSize: '1rem', lineHeight: 1.85, color: 'var(--secondary)', marginBottom: '1.5rem' }}>
              Com mais de uma década de dedicação ao movimento consciente, Patrícia Ferreira construiu uma metodologia que une a precisão técnica à sensibilidade do cuidado individualizado. Cada aluno é tratado como único, com planos de trabalho adaptados às suas necessidades e objetivos.
            </p>
            <p style={{ fontFamily: "'Manrope', sans-serif", fontSize: '1rem', lineHeight: 1.85, color: 'var(--secondary)', marginBottom: '2.5rem' }}>
              Formada pelo Instituto Brasileiro de Pilates e especializada em Pilates Clínico para Reabilitação, Patrícia acredita que o movimento é medicina. Seu estúdio é um espaço de acolhimento onde o corpo e a mente encontram harmonia.
            </p>

            {/* Counter stats */}
            <div className="grid grid-cols-3 gap-4 mb-3">
              {[
                { value: alunos, suffix: '+', label: 'Alunos' },
                { value: anos, suffix: '+', label: 'Anos' },
                { value: modalidades, suffix: '', label: 'Modalidades' },
              ].map((stat) => (
                <div key={stat.label} style={{ textAlign: 'center', padding: '1.25rem', background: '#fff', borderRadius: '1rem', boxShadow: 'var(--shadow)' }}>
                  <div className="counter-number">{stat.value}{stat.suffix}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--secondary)', opacity: 0.7, marginTop: '0.35rem', fontWeight: 500 }}>{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Certifications */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.6rem', marginTop: '1.5rem' }}>
              {['CREF Certificada', 'Pilates Clínico', 'Reabilitação Postural', 'Pós-Operatório'].map((tag) => (
                <span key={tag} style={{ background: 'rgba(104,69,46,0.08)', color: 'var(--primary)', borderRadius: '100px', padding: '0.45rem 1rem', fontSize: '0.8rem', fontWeight: 600 }}>
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About
