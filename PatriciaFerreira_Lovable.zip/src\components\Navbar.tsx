import React, { useEffect, useRef, useState } from 'react'

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const navRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const closeMenu = () => setMenuOpen(false)

  return (
    <nav
      ref={navRef}
      className={`site-nav${scrolled ? ' scrolled' : ''}`}
      aria-label="Navegação principal"
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a
          href="#hero"
          className="flex items-center gap-3"
          style={{ cursor: 'none', position: 'relative', zIndex: 1002 }}
          aria-label="Patrícia Ferreira Pilates - Início"
          onClick={closeMenu}
        >
          <div
            style={{
              width: 38,
              height: 38,
              borderRadius: 10,
              background: 'var(--primary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fcf9f4" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              <circle cx="12" cy="12" r="10" />
              <ellipse cx="12" cy="12" rx="4" ry="10" />
              <line x1="2" y1="12" x2="22" y2="12" />
            </svg>
          </div>
          <div>
            <div style={{ fontFamily: "'Noto Serif', serif", fontWeight: 700, fontSize: '0.95rem', color: 'var(--primary)', lineHeight: 1.1 }}>
              Patrícia Ferreira
            </div>
            <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--secondary)', opacity: 0.65 }}>
              Pilates
            </div>
          </div>
        </a>

        {/* Nav links */}
        <div className={`nav-links flex items-center gap-8${menuOpen ? ' open' : ''}`} role="menubar">
          <a href="#sobre" className="nav-link" role="menuitem" onClick={closeMenu}>Sobre</a>
          <a href="#metodologia" className="nav-link" role="menuitem" onClick={closeMenu}>Metodologia</a>
          <a href="#planos" className="nav-link" role="menuitem" onClick={closeMenu}>Planos</a>
          <a href="#depoimentos" className="nav-link" role="menuitem" onClick={closeMenu}>Depoimentos</a>
          <a href="#contato" className="nav-link" role="menuitem" onClick={closeMenu}>Contato</a>
          <a href="#contato" className="btn-primary" role="menuitem" onClick={closeMenu}>Agende uma Aula</a>
        </div>

        {/* Hamburger */}
        <button
          className={`hamburger${menuOpen ? ' open' : ''}`}
          aria-label="Abrir menu"
          aria-expanded={menuOpen}
          aria-controls="nav-links"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </nav>
  )
}

export default Navbar
