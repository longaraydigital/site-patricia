import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Stats from './components/Stats'
import About from './components/About'
import Methodology from './components/Methodology'
import Pricing from './components/Pricing'
import Testimonials from './components/Testimonials'
import Gallery from './components/Gallery'
import Contact from './components/Contact'
import Footer from './components/Footer'

gsap.registerPlugin(ScrollTrigger)

const App: React.FC = () => {
  const cursorRef = useRef<HTMLDivElement>(null)
  const cursorRingRef = useRef<HTMLDivElement>(null)

  // Custom cursor
  useEffect(() => {
    const cursor = cursorRef.current
    const cursorRing = cursorRingRef.current
    if (!cursor || !cursorRing) return

    let mouseX = 0
    let mouseY = 0
    let ringX = 0
    let ringY = 0
    let rafId: number

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX
      mouseY = e.clientY
      cursor.style.left = mouseX + 'px'
      cursor.style.top = mouseY + 'px'
    }

    function animateRing() {
      ringX += (mouseX - ringX) * 0.12
      ringY += (mouseY - ringY) * 0.12
      cursorRing.style.left = ringX + 'px'
      cursorRing.style.top = ringY + 'px'
      rafId = requestAnimationFrame(animateRing)
    }

    document.addEventListener('mousemove', handleMouseMove)
    rafId = requestAnimationFrame(animateRing)

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      cancelAnimationFrame(rafId)
    }
  }, [])

  return (
    <>
      {/* Custom cursor */}
      <div id="cursor" ref={cursorRef} aria-hidden="true" />
      <div id="cursor-ring" ref={cursorRingRef} aria-hidden="true" />

      <Navbar />
      <main>
        <Hero />
        <Stats />
        <About />
        <Methodology />
        <Pricing />
        <Testimonials />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </>
  )
}

export default App
