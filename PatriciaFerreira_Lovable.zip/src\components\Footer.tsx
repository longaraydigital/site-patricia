import React from 'react'

const Footer: React.FC = () => {
  return (
    <footer className="site-footer" style={{ padding: '4rem 0 2rem' }} role="contentinfo">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-10 pb-8" style={{ borderBottom: '1px solid rgba(252,249,244,0.12)' }}>

          {/* Brand */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem', marginBottom: '1.25rem' }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: 'rgba(252,249,244,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }} aria-hidden="true">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(252,249,244,0.9)" strokeWidth="1.8" strokeLinecap="round">
                  <circle cx="12" cy="12" r="10" />
                  <ellipse cx="12" cy="12" rx="4" ry="10" />
                  <line x1="2" y1="12" x2="22" y2="12" />
                </svg>
              </div>
              <div>
                <div style={{ fontFamily: "'Noto Serif', serif", fontWeight: 700, fontSize: '1rem', color: '#fcf9f4', lineHeight: 1.1 }}>Patrícia Ferreira</div>
                <div style={{ fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(252,249,244,0.45)' }}>Pilates</div>
              </div>
            </div>
            <p style={{ fontSize: '0.875rem', lineHeight: 1.75, color: 'rgba(252,249,244,0.6)', maxWidth: 260 }}>
              A Essência do Bem-Estar e Equilíbrio. Movimento consciente para uma vida plena.
            </p>
          </div>

          {/* Navigation links */}
          <div>
            <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(252,249,244,0.45)', marginBottom: '1.25rem' }}>Navegação</div>
            <nav aria-label="Links do rodapé">
              <a href="#sobre" className="footer-link">Sobre Patrícia</a>
              <a href="#metodologia" className="footer-link">Nossa Metodologia</a>
              <a href="#planos" className="footer-link">Planos e Preços</a>
              <a href="#depoimentos" className="footer-link">Depoimentos</a>
              <a href="#contato" className="footer-link">Contato &amp; Agendamento</a>
            </nav>
          </div>

          {/* Contact info */}
          <div>
            <div style={{ fontFamily: "'Manrope', sans-serif", fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(252,249,244,0.45)', marginBottom: '1.25rem' }}>Informações</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem', fontSize: '0.875rem', color: 'rgba(252,249,244,0.65)' }}>
                <span style={{ flexShrink: 0, marginTop: '0.1rem' }} aria-hidden="true">📍</span>
                <span>Av. da Elegância, 1200 — Jardins<br />São Paulo, SP</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.875rem', color: 'rgba(252,249,244,0.65)' }}>
                <span aria-hidden="true">📞</span>
                <span>+55 (11) 99999-8888</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.875rem', color: 'rgba(252,249,244,0.65)' }}>
                <span aria-hidden="true">🕐</span>
                <span>Seg–Sex 7h–20h · Sáb 8h–14h</span>
              </div>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '1rem', paddingTop: '1.75rem' }}>
          <p style={{ fontSize: '0.8rem', color: 'rgba(252,249,244,0.4)' }}>© 2024 Patrícia Ferreira Pilates. Todos os direitos reservados.</p>
          <div style={{ display: 'flex', gap: '1.25rem' }}>
            <a href="#" className="footer-link" style={{ margin: 0, fontSize: '0.8rem' }}>Política de Privacidade</a>
            <a href="#" className="footer-link" style={{ margin: 0, fontSize: '0.8rem' }}>Termos de Uso</a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
